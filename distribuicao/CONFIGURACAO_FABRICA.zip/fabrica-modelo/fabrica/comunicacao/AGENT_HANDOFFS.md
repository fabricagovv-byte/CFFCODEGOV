# Transferências de trabalho (handoffs)

Registro gerado pela CLI. Não edite entradas antigas.
