# Decisões registradas

Registro gerado pela CLI. Não edite entradas antigas.
